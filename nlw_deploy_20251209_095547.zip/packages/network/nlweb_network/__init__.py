"""NLWeb Network - Transport and protocol adapters for NLWeb."""

__version__ = "0.5.0"
